//
//  ViewController.swift
//  Navegacion
//
//  Created by Alumno on 9/29/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class RojoController: UIViewController {

    var nombre = ""
    var matricula = ""
    var promedio = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func DoTapJose(_ sender: Any) {
        
        nombre = "Jose"
        matricula = "123"
        promedio = "8.5"
        self.performSegue(withIdentifier: "GoToAzul", sender: self)
    }
    
    
    @IBAction func DoTapAna(_ sender: Any) {
        
        nombre = "Ana"
        matricula = "954"
        promedio = "7.4"
        self.performSegue(withIdentifier: "GoToAzul", sender: self)
    }
    
    @IBAction func DoTapPedro(_ sender: Any) {
        
        nombre = "Pedro"
        matricula = "333"
        promedio = "5.5"
        self.performSegue(withIdentifier: "GoToAzul", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino = segue.destination as! AzulController
        destino.nombre = nombre
        destino.promedio = promedio
        destino.matricula = matricula
        
        
    }
    
}

